INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1000, N'Yash Khokale', N'06/19/1997', N'yashkhokale@gmail.com', N'170, Vakhar Bhag, Sangli.', 6174126121)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1001, N'Anish Naik', N'09/12/1997', N'naik.ani@husky.neu.edu', N'451, Park Drive, Boston, MA', 6172596134)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1002, N'Jonny Malhotra', N'05/02/2008', N'jonnymalhotra@gmail.com', N'432, Boylston Street, Boston, MA', 6174126122)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1003, N'Cash Johnson', N'06/10/2019', N'cashj@gmail.com', N'Pragati colony, Sangli, MH', 6174126123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1004, N'Rock K', N'10/11/2020', N'rocky@gmail.com', N'Fenway Park, boston, MA', 8421564564)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1005, N'Hunter Kelen', N'09/08/2001', N'hunty@gmail.com', N'250, Emerald Necklace, boston, MA', 9876543210)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1006, N'Joey Tribianni ', N'04/01/1998', N'joeyhowudoing@gmail.com', N'Central Park, New York City, NY', 1430001430)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1007, N'Ross Geller', N'04/02/1998', N'rossunagi@gmail.com', N'Ungly guy, NYC, NY', 3426517894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1008, N'Chandler Bing', N'04/03/1998', N'iknewit@gmail.com', N'Monica''s Apt, NYC, NY', 5461237894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1009, N'Gunther ', N'04/04/1998', N'iloveracheal@gmail.com', N'Centerl Perk, Down town, NYC, NY', 8456482123)
GO

INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1000, N'Yash Khokale', N'06/19/1997', N'yashkhokale@gmail.com', N'170, Vakhar Bhag, Sangli.', 6174126121)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1001, N'Anish Naik', N'09/12/1997', N'naik.ani@husky.neu.edu', N'451, Park Drive, Boston, MA', 6172596134)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1002, N'Jonny Malhotra', N'05/02/2008', N'jonnymalhotra@gmail.com', N'432, Boylston Street, Boston, MA', 6174126122)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1003, N'Cash Johnson', N'06/10/2019', N'cashj@gmail.com', N'Pragati colony, Sangli, MH', 6174126123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1004, N'Rock K', N'10/11/2020', N'rocky@gmail.com', N'Fenway Park, boston, MA', 8421564564)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1005, N'Hunter Kelen', N'09/08/2001', N'hunty@gmail.com', N'250, Emerald Necklace, boston, MA', 9876543210)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1006, N'Joey Tribianni ', N'04/01/1998', N'joeyhowudoing@gmail.com', N'Central Park, New York City, NY', 1430001430)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1007, N'Ross Geller', N'04/02/1998', N'rossunagi@gmail.com', N'Ungly guy, NYC, NY', 3426517894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1008, N'Chandler Bing', N'04/03/1998', N'iknewit@gmail.com', N'Monica''s Apt, NYC, NY', 5461237894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1009, N'Gunther ', N'04/04/1998', N'iloveracheal@gmail.com', N'Centerl Perk, Down town, NYC, NY', 8456482123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1010, N'Yash Khokale', N'06/19/1997', N'yashkhokale@gmail.com', N'170, Vakhar Bhag, Sangli.', 6174126121)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1011, N'Anish Naik', N'09/12/1997', N'naik.ani@husky.neu.edu', N'451, Park Drive, Boston, MA', 6172596134)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1012, N'Jonny Malhotra', N'05/02/2008', N'jonnymalhotra@gmail.com', N'432, Boylston Street, Boston, MA', 6174126122)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1013, N'Cash Johnson', N'06/10/2019', N'cashj@gmail.com', N'Pragati colony, Sangli, MH', 6174126123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1014, N'Rock K', N'10/11/2020', N'rocky@gmail.com', N'Fenway Park, boston, MA', 8421564564)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1015, N'Hunter Kelen', N'09/08/2001', N'hunty@gmail.com', N'250, Emerald Necklace, boston, MA', 9876543210)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1016, N'Joey Tribianni ', N'04/01/1998', N'joeyhowudoing@gmail.com', N'Central Park, New York City, NY', 1430001430)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1017, N'Ross Geller', N'04/02/1998', N'rossunagi@gmail.com', N'Ungly guy, NYC, NY', 3426517894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1018, N'Chandler Bing', N'04/03/1998', N'iknewit@gmail.com', N'Monica''s Apt, NYC, NY', 5461237894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1019, N'Gunther ', N'04/04/1998', N'iloveracheal@gmail.com', N'Centerl Perk, Down town, NYC, NY', 8456482123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1020, N'Yash Khokale', N'06/19/1997', N'yashkhokale@gmail.com', N'170, Vakhar Bhag, Sangli.', 6174126121)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1021, N'Anish Naik', N'09/12/1997', N'naik.ani@husky.neu.edu', N'451, Park Drive, Boston, MA', 6172596134)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1022, N'Jonny Malhotra', N'05/02/2008', N'jonnymalhotra@gmail.com', N'432, Boylston Street, Boston, MA', 6174126122)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1023, N'Cash Johnson', N'06/10/2019', N'cashj@gmail.com', N'Pragati colony, Sangli, MH', 6174126123)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1024, N'Rock K', N'10/11/2020', N'rocky@gmail.com', N'Fenway Park, boston, MA', 8421564564)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1025, N'Hunter Kelen', N'09/08/2001', N'hunty@gmail.com', N'250, Emerald Necklace, boston, MA', 9876543210)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1026, N'Joey Tribianni ', N'04/01/1998', N'joeyhowudoing@gmail.com', N'Central Park, New York City, NY', 1430001430)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1027, N'Ross Geller', N'04/02/1998', N'rossunagi@gmail.com', N'Ungly guy, NYC, NY', 3426517894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1028, N'Chandler Bing', N'04/03/1998', N'iknewit@gmail.com', N'Monica''s Apt, NYC, NY', 5461237894)
GO
INSERT [dbo].[User] ([User_Id], [User_Name], [Date_of_Birth], [Email_Address], [Address], [Contact_Number]) VALUES (1029, N'Gunther ', N'04/04/1998', N'iloveracheal@gmail.com', N'Centerl Perk, Down town, NYC, NY', 8456482123)
GO

select * from [dbo].[User] 



INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3000, N'1-bhk', N'Ap #387-1671 Amet Rd.', N'AR', N'Fayetteville', N'72005 ', N'12%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3001, N'3-bhk', N'Ap #913-8113 Sed St.', N'Vermont', N'Montpelier', N'93499 ', N'15%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3002, N'Studio-Apt', N'P.O. Box 726, 3426 Egestas. Av.', N'Idaho', N'Boise', N'48868 ', N'15%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3003, N'2-bhk', N'Ap #408-7060 Et Ave', N'LA', N'New Orleans', N'57620 ', N'2%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3004, N'Studio-Apt', N'P.O. Box 580, 5135 Lobortis St.', N'Maine', N'Bangor', N'91181 ', N'10%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3005, N'3-bhk', N'P.O. Box 870, 243 Nisl Rd.', N'WA', N'Tacoma', N'42051 ', N'10%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3006, N'4-bhk', N'8166 Aliquet Rd.', N'WI', N'Milwaukee', N'33516 ', N'20%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3007, N'3-bhk', N'P.O. Box 771, 4536 Donec Rd.', N'AK', N'Fairbanks', N'99610 ', N'2%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3008, N'3-bhk', N'P.O. Box 617, 8474 Enim Rd.', N'Idaho', N'Boise', N'37468 ', N'20%')
GO
INSERT [dbo].[Property] ([Property_Id], [Property_Name], [Street_Name], [State_Name], [City_Name], [Zipcode], [Crime_Rate]) VALUES (3009, N'4-bhk', N'171-7377 Libero Rd.', N'Illinois', N'Rockford', N'10628 ', N'20%')
GO

select * from [dbo].[Property] 


INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (100, N'Trader Joe''s<3miles', N'Chase< 2mile', N'Red_Line<2miles', N'<1.5miles', N'<4miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (101, N'Whole Food<1mile', N'Santander<2 mile', N'Orange-Line<1miles', N'<1.5miles', N'<5miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (102, 3003, N'Walgreens<3miles', N'Chase< 2mile', N'Red_Line<2miles', N'<3miles', N'<3miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (103,3009, N'Stop-n-shop<2miles', N'Bofa< 1 mile', N'Orange-Line<1miles', N'<1miles', N'<4miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (104, 3001, N'Walmart<1mile', N'Bofa< 1 mile', N'Red_Line<2miles', N'<1miles', N'<6miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (105, 3007,N'Indian Store<2miles', N'Chase< 2mile', N'Orange-Line<1miles', N'<2miles', N'<1.5miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (106, 3004, N'Whole Food<1mile', N'Bofa< 1 mile', N'Orange-Line<1miles', N'<2miles', N'<2miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (107, 3008, N'Trader Joe''s<3miles', N'Bofa< 1 mile', N'Orange-Line<1miles', N'<2miles', N'<1miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (108, 3002, N'Whole Food<1mile', N'Chase< 2mile', N'CommuterRail<3miles', N'<2miles', N'<4miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (109, 3000, N'Trader Joe''s<3miles', N'Bofa< 1 mile', N'Red_Line<2miles', N'<3miles', N'<6miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id],[Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (110, 3005, N'Trader Joe''s<3miles', N'Santander<2 mile', N'Orange-Line<1miles', N'<2miles', N'<1.5miles', N'Not Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (111, N'Walgreens<3miles', N'Santander<2 mile', N'T-Line<1miles', N'<1.5miles', N'<3miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id],[Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (112, N'Trader Joe''s<3miles', N'Santander<2 mile', N'CommuterRail<3miles', N'<3miles', N'<6miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id], [Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (113, N'Indian Store<2miles', N'Santander<2 mile', N'CommuterRail<3miles', N'<1.5miles', N'<1.5miles', N'Available')
GO
INSERT [dbo].[Public_Facilities] ([Facility_Id], [Property_Id],[Grocery_store], [Bank], [Subway_Station], [Bus_Stop], [Hospital], [Gym_facility]) VALUES (114, N'American Store<2miles', N'Bofa< 1 mile', N'T-Line<1miles', N'<1miles', N'<1miles', N'Available')
GO

select * from [dbo].[Public_Facilities]
 select * from Property


INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2000, 1000, 3000, 286, 24, 'Old-Construction', 2000, 'N', 4, 1, CAST(N'2019-04-27T00:00:00.000' AS DateTime), CAST(N'2020-02-22T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2001, 1001, 3001, 127, 34, 'Old-Construction', 2222, 'Y', 1, 1, CAST(N'2019-06-29T00:00:00.000' AS DateTime), CAST(N'2019-04-04T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2002, 1002, 3002, 170, 36, 'Old-Construction', 2250, 'N', 4, 1, CAST(N'2019-06-21T00:00:00.000' AS DateTime), CAST(N'2020-06-22T00:00:00.000' AS DateTime), N'N')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2003, 1003, 3003, 371, 20, 'Not-Furnished', 1890, 'N', 1, 1, CAST(N'2019-09-10T00:00:00.000' AS DateTime), CAST(N'2019-08-08T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2004, 1004, 3004, 171, 50,'Newly Constructed', 3123, 'Y', 3, 1, CAST(N'2020-03-02T00:00:00.000' AS DateTime), CAST(N'2020-02-01T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2005, 1005, 3005, 328, 49, 'Furnished Apt', 2800, 'Y', 1, 1, CAST(N'2019-09-25T00:00:00.000' AS DateTime), CAST(N'2020-11-10T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2006, 1006, 3006, 356, 14, 'Not-Furnished', 1540, 'Y', 4, 1, CAST(N'2019-07-14T00:00:00.000' AS DateTime), CAST(N'2020-05-31T00:00:00.000' AS DateTime), N'N')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2007, 1007, 3007, 259, 19, 'Furnished Apt', 1980, 'N', 4, 1, CAST(N'2019-05-25T00:00:00.000' AS DateTime), CAST(N'2020-04-17T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2008, 1008, 3008, 430, 43, 'Newly Constructed', 2433, 'Y', 4, 1,CAST(N'2019-08-06T00:00:00.000' AS DateTime), CAST(N'2020-10-07T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2009, 1009, 3009, 108, 16, 'Old-Construction', 2456, 'Y', 4, 1,  CAST(N'2019-08-17T00:00:00.000' AS DateTime), CAST(N'2019-08-05T00:00:00.000' AS DateTime), N'Y')



INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2010, 1010, 3010, 286, 24, 'Old-Construction', 2000, 'N', 4, 1, CAST(N'2019-04-27T00:00:00.000' AS DateTime), CAST(N'2020-02-22T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2011, 1011, 3011, 127, 34, 'Old-Construction', 2222, 'Y', 1, 1, CAST(N'2019-06-29T00:00:00.000' AS DateTime), CAST(N'2019-04-04T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2012, 1012, 3012, 170, 36, 'Old-Construction', 2250, 'N', 4, 1, CAST(N'2019-06-21T00:00:00.000' AS DateTime), CAST(N'2020-06-22T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2013, 1013, 3013, 371, 20, 'Not-Furnished', 1890, 'N', 1, 1, CAST(N'2019-09-10T00:00:00.000' AS DateTime), CAST(N'2019-08-08T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2014, 1014, 3014, 171, 50,'Newly Constructed', 3123, 'Y', 3, 1, CAST(N'2020-03-02T00:00:00.000' AS DateTime), CAST(N'2020-02-01T00:00:00.000' AS DateTime), N'N')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2015, 1015, 3015, 328, 49, 'Furnished Apt', 2800, 'Y', 1, 1, CAST(N'2019-09-25T00:00:00.000' AS DateTime), CAST(N'2020-11-10T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2016, 1016, 3016, 356, 14, 'Not-Furnished', 1540, 'Y', 4, 1, CAST(N'2019-07-14T00:00:00.000' AS DateTime), CAST(N'2020-05-31T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2017, 1017, 3017, 259, 19, 'Furnished Apt', 1980, 'N', 4, 1, CAST(N'2019-05-25T00:00:00.000' AS DateTime), CAST(N'2020-04-17T00:00:00.000' AS DateTime), N'N')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2018, 1018, 3018, 430, 43, 'Newly Constructed', 2433, 'Y', 4, 1,CAST(N'2019-08-06T00:00:00.000' AS DateTime), CAST(N'2020-10-07T00:00:00.000' AS DateTime), N'Y')
INSERT [dbo].[Unit] ([Unit_Id], [User_Id], [Property_Id], [Unit_Number], [Unit_Floor_Number], [Unit_Description], [Carpet_area], [Pets_Allowed], [No_of_bedrooms], [No_of_bathrooms], [Date_of_Posting], [Date_Available_from], [Availability]) VALUES (2019, 1019, 3019, 108, 16, 'Old-Construction', 2456, 'Y', 4, 1,  CAST(N'2019-08-17T00:00:00.000' AS DateTime), CAST(N'2019-08-05T00:00:00.000' AS DateTime), N'Y')

select * from [Unit]




INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4000, 2000, CAST(N'2020-04-16T00:00:00.000' AS DateTime), CAST(N'2022-07-02T00:00:00.000' AS DateTime), 12, 1287, 1000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4001, 2001, CAST(N'2020-12-28T00:00:00.000' AS DateTime), CAST(N'2021-11-23T00:00:00.000' AS DateTime), 6, 874, 1000, NULL, N'Y', 2)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4002, 2002, CAST(N'2021-01-23T00:00:00.000' AS DateTime), CAST(N'2022-03-24T00:00:00.000' AS DateTime), 18, 1697, 1000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4003, 2003, CAST(N'2020-10-18T00:00:00.000' AS DateTime), CAST(N'2022-08-21T00:00:00.000' AS DateTime), 12, 1282, 1000, NULL, N'Y', 2)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4004, 2004, CAST(N'2021-02-08T00:00:00.000' AS DateTime), CAST(N'2021-11-18T00:00:00.000' AS DateTime), 6, 1840, 2000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4005, 2005, CAST(N'2021-01-31T00:00:00.000' AS DateTime), CAST(N'2022-05-25T00:00:00.000' AS DateTime), 12, 1279, 3000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4006, 2006, CAST(N'2020-06-23T00:00:00.000' AS DateTime), CAST(N'2021-11-16T00:00:00.000' AS DateTime), 12, 1952, 2000, NULL, N'Y', 4)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4007, 2007, CAST(N'2021-03-28T00:00:00.000' AS DateTime), CAST(N'2022-07-12T00:00:00.000' AS DateTime), 12, 1307, 2000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4008, 2008, CAST(N'2020-05-05T00:00:00.000' AS DateTime), CAST(N'2022-06-10T00:00:00.000' AS DateTime), 6, 1665, 2000, NULL, N'Y', 3)
GO
INSERT [dbo].[Lease_Details] ([Lease_Id], [Unit_Id], [StartDate], [EndDate], [Term], [Monthly_Rent], [Security_Deposit_Amount], [Pet_Deposit], [Is_sub_leasing_allowed], [Required_people_on_lease]) VALUES (4009, 2009, CAST(N'2020-09-24T00:00:00.000' AS DateTime), CAST(N'2021-11-10T00:00:00.000' AS DateTime), 18, 1106, 3000, NULL, N'Y', 4)
GO

select * from [dbo].[Lease_Details]

INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5000, 4000, N'Cash', CAST(N'2020-04-05T00:00:00.000' AS DateTime), 1080, 53)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5001, 4001, N'Online Transaction', CAST(N'2020-01-11T00:00:00.000' AS DateTime), 1267, 75)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5002, 4002, N'Check', CAST(N'2020-05-02T00:00:00.000' AS DateTime), 1372, 70)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5003, 4003, N'Cash', CAST(N'2020-05-03T00:00:00.000' AS DateTime), 1081, 100)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5004, 4004, N'DD', CAST(N'2020-09-25T00:00:00.000' AS DateTime), 1995, 65)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5005, 4005, N'Online Transaction', CAST(N'2020-02-03T00:00:00.000' AS DateTime), 1863, 52)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5006, 4006, N'Online Transaction', CAST(N'2020-04-05T00:00:00.000' AS DateTime), 1611, 85)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5007, 4007, N'Online Transaction', CAST(N'2020-10-06T00:00:00.000' AS DateTime), 1717, 85)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5008, 4008, N'DD', CAST(N'2020-04-08T00:00:00.000' AS DateTime), 1565, 74)
GO
INSERT [dbo].[Lease_Payment] ([Lease_Payment_Id], [Lease_Id], [Payment_Type], [Payment_Date], [Payment_Amount], [Late_Fees]) VALUES (5009, 4009, N'DD', CAST(N'2020-11-01T00:00:00.000' AS DateTime), 1930, 98)
GO

select * from [dbo].[Lease_Payment] 

INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1002, 2800, N'432, Boylston Street, Boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1004, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1008, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1010, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1012, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1014, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1018, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1020, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1022, 1400, N'Fenway Park, boston, MA')
INSERT [dbo].[Agent] ([User_Id], [Broker_Fee], [Office_Address]) VALUES (1024, 1400, N'Fenway Park, boston, MA')
select * from Agent


INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1000, 2400)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1001, 3200)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1003, 2400)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1005, 3200)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1007, 2400)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1009, 3200)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1011, 2400)
INSERT [dbo].[Owner] ([User_Id], [Price_Expectation]) VALUES (1013, 3200)


INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (1, CAST(N'2019-08-02T00:00:00.000' AS DateTime), 1000, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (2, CAST(N'2019-12-23T00:00:00.000' AS DateTime), 1001, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (3, CAST(N'2019-12-21T00:00:00.000' AS DateTime), 1002, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (4, CAST(N'2020-02-25T00:00:00.000' AS DateTime), 1003, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (5, CAST(N'2019-11-23T00:00:00.000' AS DateTime), 1004, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (6, CAST(N'2019-11-12T00:00:00.000' AS DateTime), 1005, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (7, CAST(N'2019-08-21T00:00:00.000' AS DateTime), 1006, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (8, CAST(N'2019-08-18T00:00:00.000' AS DateTime), 1007, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (9, CAST(N'2020-01-05T00:00:00.000' AS DateTime), 1008, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (10, CAST(N'2019-04-05T00:00:00.000' AS DateTime), 1009, N'')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (11, CAST(N'2020-06-04T00:00:00.000' AS DateTime), 1009, N'Raised a Maintenance Request')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (12, CAST(N'2020-07-09T00:00:00.000' AS DateTime), 1004, N'Payment queries solved')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (13, CAST(N'2020-06-06T00:00:00.000' AS DateTime), 1003, N'Raised a Maintenance Request')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (14, CAST(N'2020-09-09T00:00:00.000' AS DateTime), 1005, N'Payment queries solved')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (15, CAST(N'2019-03-04T00:00:00.000' AS DateTime), 1006, N'Maintenance Request')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (16, CAST(N'2008-07-06T00:00:00.000' AS DateTime), 1002, N'Payment queries solved')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (17, CAST(N'2003-07-06T00:00:00.000' AS DateTime), 1001, N'Maintenance Request')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (18, CAST(N'2006-02-03T00:00:00.000' AS DateTime), 1008, N'Feedback')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (19, CAST(N'2004-01-01T00:00:00.000' AS DateTime), 1007, N'Lease requirements list')
GO
INSERT [dbo].[Appointment_Schedule] ([Appointment_Id], [Scheduled_Date], [User_Id], [Meeting_Notes]) VALUES (20, CAST(N'1997-01-09T00:00:00.000' AS DateTime), 1000, N'personal requirements')
GO




INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (500, N'Y', N'Y', N'Y', N'Y', N'Y', N'Y', N'N', N'N', N'N', N'N', N'Y')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (501, N'Y', N'N', N'Y', N'N', N'Y', N'Y', N'Y', N'Y', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (502, N'Y', N'Y', N'Y', N'N', N'Y', N'Y', N'Y', N'Y', N'Y', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (503, N'Y', N'Y', N'N', N'Y', N'N', N'Y', N'Y', N'N', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (504, N'Y', N'N', N'N', N'Y', N'Y', N'N', N'Y', N'Y', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (505, N'N', N'Y', N'N', N'Y', N'N', N'Y', N'Y', N'Y', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (506, N'N', N'N', N'Y', N'Y', N'N', N'Y', N'Y', N'N', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (507, N'N', N'N', N'Y', N'Y', N'N', N'N', N'Y', N'N', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (508, N'N', N'Y', N'N', N'N', N'N', N'Y', N'N', N'N', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (509, N'Y', N'Y', N'Y', N'Y', N'N', N'Y', N'Y', N'N', N'Y', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3000, N'Y', N'N', N'Y', N'N', N'N', N'Y', N'Y', N'N', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3001, N'Y', N'N', N'N', N'Y', N'N', N'Y', N'Y', N'N', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3002, N'N', N'Y', N'Y', N'N', N'N', N'Y', N'Y', N'N', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3003, N'N', N'Y', N'N', N'Y', N'Y', N'N', N'Y', N'N', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3004, N'Y', N'N', N'Y', N'N', N'Y', N'N', N'Y', N'N', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3005, N'Y', N'N', N'N', N'Y', N'Y', N'N', N'N', N'Y', N'N', N'Y', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3006, N'N', N'Y', N'Y', N'N', N'N', N'Y', N'N', N'Y', N'N', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3007, N'N', N'Y', N'N', N'Y', N'N', N'Y', N'N', N'Y', N'Y', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3008, N'Y', N'N', N'Y', N'N', N'N', N'Y', N'N', N'Y', N'Y', N'N', N'N')
GO
INSERT [dbo].[Features] ([Features_Id], [Parking_Facility], [Air_Conditioning], [Central_Heating], [Carpet_floor], [Hardwood_floor], [InUnit_Fireplace], [InUnit_Garden], [InUnit_Laundary], [Ceiling_Fan], [Pets_Allowed], [Walkin_Closet]) VALUES (3009, N'Y', N'N', N'N', N'Y', N'Y', N'N', N'N', N'Y', N'Y', N'Y', N'N')
GO




INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2000, 505)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2001, 507)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2002, 500)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2003, 508)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2004, 509)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2005, 506)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2006, 504)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2007, 503)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2008, 501)
GO
INSERT [dbo].[Has_Features] ([Unit_Id], [Features_Id]) VALUES (2009, 502)
GO




INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) VALUES (2001, N'Y')
GO
INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) VALUES (2004, N'N')
GO
INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) VALUES (2006, N'Y')
GO
INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) VALUES (2007, N'Y')
GO
INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) VALUES (2009, N'N')
GO


INSERT [dbo].[Apartment] ([Unit_Id], [Has_in_unit_laundry]) 
VALUES (2010,'Y'),
        (2012,'N'),
        (2014,'Y'),
        (2016,'N'),
        (2018,'Y');


INSERT [dbo].[House] ([Unit_Id], [Backyard], [Parking]) VALUES (2000, N'Y', N'N')
GO
INSERT [dbo].[House] ([Unit_Id], [Backyard], [Parking]) VALUES (2002, N'Y', N'Y')
GO
INSERT [dbo].[House] ([Unit_Id], [Backyard], [Parking]) VALUES (2003, N'N', N'N')
GO
INSERT [dbo].[House] ([Unit_Id], [Backyard], [Parking]) VALUES (2005, N'Y', N'Y')
GO
INSERT [dbo].[House] ([Unit_Id], [Backyard], [Parking]) VALUES (2008, N'N', N'Y')
GO


INSERT [dbo].[House] ([Unit_Id], [Backyard],[Parking]) 
VALUES (2011,'Y','N'),
        (2013,'N','Y'),
        (2015,'Y','N'),
        (2017,'N','N'),
        (2019,'Y','Y');




		
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3000, 109, 72005)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3001, 100, 93499)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3002, 108, 48868)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3003, 107, 57620)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3004, 104, 91181)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3005, 103, 42051)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3006, 102, 33516)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3007, 101, 99610)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3008, 106, 37468)
GO
INSERT [dbo].[Has_Zipcode] ([Property_Id], [Facility_Id], [Zipcode]) VALUES (3009, 105, 10628)
GO



select * from [dbo].[Client] 

INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1006, 'In-house laundry unit required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1015, '3BHK required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1016, 'Backyard and parking lot required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1017, '4BHK with 1.5 bath required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1019, 'In-house laundry unit required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1020, 'Microwave required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1021, 'Parrking lot required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1023, 'Electric stove and microwave required')
GO
INSERT [dbo].[Client] ([User_Id], [Client_Wishlist]) VALUES (1025, 'Parking lot and backyard required')
GO